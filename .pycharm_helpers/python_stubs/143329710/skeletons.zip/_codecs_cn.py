# encoding: utf-8
# module _codecs_cn
# from /usr/local/lib/python3.6/lib-dynload/_codecs_cn.cpython-36m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_gb18030ext = None # (!) real value is ''

__map_gb2312 = None # (!) real value is ''

__map_gbcommon = None # (!) real value is ''

__map_gbkext = None # (!) real value is ''

__spec__ = None # (!) real value is ''

