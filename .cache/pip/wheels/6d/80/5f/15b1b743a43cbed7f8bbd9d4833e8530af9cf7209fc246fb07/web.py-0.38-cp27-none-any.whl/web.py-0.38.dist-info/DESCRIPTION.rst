Think about the ideal way to write a web app. Write the code to make it happen.


