Boost automatically toots from users of the Mastodon social network


